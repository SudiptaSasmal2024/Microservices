package com.sasmal.milestone.Milestone_SBA_retest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MilestoneSbaRetestApplicationTests {

	@Test
	void contextLoads() {
	}

}
