package com.sasmal.Repository;


import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.sasmal.Entity.SasmalProductEntity;

public interface SasmalProductEntityRepository extends JpaRepository<SasmalProductEntity, Integer>{
///
	List<SasmalProductEntity> findById(int id);
	

}
