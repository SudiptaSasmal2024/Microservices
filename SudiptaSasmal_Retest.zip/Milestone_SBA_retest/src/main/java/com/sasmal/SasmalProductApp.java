package com.sasmal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sasmal.DTO.SasmalProductDTO;
import com.sasmal.Service.SasmalProductService;






@SpringBootApplication
@RestController
@CrossOrigin
public class SasmalProductApp {
	
	@Autowired

	private SasmalProductService productService;
	

	public static void main(String[] args) {
		
	ConfigurableApplicationContext context =	SpringApplication.run(SasmalProductApp.class, args);
	SasmalProductService service = context.getBean(SasmalProductService.class);
	
	service.addProduct(new SasmalProductDTO(111, "Mobile",10000));
	service.addProduct(new SasmalProductDTO(222, "Laptop",50000));
	service.addProduct(new SasmalProductDTO(333, "Mobile",20000));
	

	
	
	
	}

	@GetMapping("/product")
	public String home() {
		return "Welcome to Product management System";
	}
	

	
}

