package com.sasmal.DAO;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.sasmal.Entity.SasmalProductEntity;
import com.sasmal.Repository.SasmalProductEntityRepository;





@Repository
public class SasmalProductDao {

	@Autowired
	private SasmalProductEntityRepository repository;

	public SasmalProductEntity addProduct(SasmalProductEntity product) {
		return repository.save(product);
	}

	public List<SasmalProductEntity> getAllProducts() {
		return repository.findAll();
	}

	public Optional<SasmalProductEntity> verifyId(Integer id) {
		return repository.findById(id);
	}
	
	public boolean deleteProduct(Integer id) {
		if (repository.existsById(id)) {
			repository.deleteById(id);
			return true;
		}
		return false;
	}

	public List<SasmalProductEntity> findById (int id){
		return repository.findById(id);
	}
}
