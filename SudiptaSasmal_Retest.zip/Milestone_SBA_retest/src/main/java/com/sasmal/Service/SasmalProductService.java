package com.sasmal.Service;


import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sasmal.DAO.SasmalProductDao;
import com.sasmal.DTO.SasmalProductDTO;
import com.sasmal.Entity.SasmalProductEntity;


import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class SasmalProductService {

	@Autowired
	private SasmalProductDao productDao;

	private ModelMapper mapper = new ModelMapper();

	public void addProduct(SasmalProductDTO product) {
		log.info("In Service Method {}", product);
		product.setName(product.getName().toUpperCase());
		SasmalProductEntity entity = mapper.map(product, SasmalProductEntity.class);
		productDao.addProduct(entity);
	}

	public List<SasmalProductEntity> getAll() {
		return productDao.getAllProducts();
	}
	
	public boolean deleteProduct(Integer id) {
		return productDao.deleteProduct(id);
	}
	public Optional<SasmalProductEntity> verifyById(Integer id) {
		return productDao.verifyId(id);
	}
}
