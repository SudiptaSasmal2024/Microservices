package com.sasmal.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sasmal.DTO.SasmalProductDTO;
import com.sasmal.Entity.SasmalProductEntity;
import com.sasmal.Service.SasmalProductService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping
@CrossOrigin
@Slf4j
public class SasmalProductController {
	
	@Autowired
	private SasmalProductService productService;
	
	@PostMapping("/product/addproduct")
	public String addProduct(@RequestBody SasmalProductDTO product) {
		log.info("In Service : {}", product);
		productService.addProduct(product);
		return "Your Record is Saved : " + product.getName();
	}
	@DeleteMapping("/product/{id}")
	public String deleteProduct(@PathVariable Integer id) {
		log.info("In Service : {}", id);	
		if(productService.deleteProduct(id)) {
			return "Your Record is deleted  : " + id ;
		}else {
			return "Your Record is Not deleted  : " + id ;
		}
	}
	
	@GetMapping("/product/{id}")
	public Optional<SasmalProductEntity> checkId(@PathVariable("id") Integer id) {
		if(productService.verifyById(id) != null) {
			
			return productService.verifyById(id);
		}
		return productService.verifyById(id); 
	}
	

	@GetMapping("/product/allproducts")
	public List<SasmalProductEntity> getEveryProducts() {
		return productService.getAll();
		
	}
	
}
