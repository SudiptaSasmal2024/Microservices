package com.soumalya.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.soumalya.entity.StudentEntity;
import com.soumalya.entity.StudentEntityRepository;

@Repository
public class StudentDao {

	@Autowired
	private StudentEntityRepository repository;

	public StudentEntity addStudent(StudentEntity student) {
		return repository.save(student);
	}

	public List<StudentEntity> getAllStudents() {
		return repository.findAll();
	}

	///
	public Optional<StudentEntity> verifyId(Integer id) {
		return repository.findById(id);
		//return repository.existsById(id);
	}
	
	public boolean deleteStudent(Integer id) {
		if (repository.existsById(id)) {
			repository.deleteById(id);
			return true;
		}
		return false;
	}

//	@Query(value = "SELECT * FROM STUDENT WHERE CITY =?, nativeQuery = true")
//	public Optional<StudentEntity> verifyCity(String city) {
//		// TODO Auto-generated method stub
//		return repository.;
//	}
	public List<StudentEntity> findByCity (String city){
		return repository.findByCity(city);
	}
}
