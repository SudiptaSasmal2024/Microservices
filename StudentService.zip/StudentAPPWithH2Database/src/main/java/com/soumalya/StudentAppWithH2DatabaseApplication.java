package com.soumalya;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.soumalya.dto.StudentDTO;
import com.soumalya.service.StudentService;

@SpringBootApplication
@RestController
@CrossOrigin
public class StudentAppWithH2DatabaseApplication {
	
	@Autowired
	private StudentService studentService;
	

	public static void main(String[] args) {
	ConfigurableApplicationContext context =	SpringApplication.run(StudentAppWithH2DatabaseApplication.class, args);
	StudentService service = context.getBean(StudentService.class);
	service.addStudent(new StudentDTO(1,6, "soumalya","sou@gmail","kolkata"));
	service.addStudent(new StudentDTO(2,45, "debu","dev@yahoo","delhi"));
	service.addStudent(new StudentDTO(3,87, "ritika","runti@gmail","mumbai"));
	service.addStudent(new StudentDTO(4,88, "preetam","paulpr@gmail","kolkata"));
	service.addStudent(new StudentDTO(5,90, "krishnendu","krish@hotmail","pune"));

	
	}

	@GetMapping("/student")
	public String home() {
		return "Welcome to Student APP";
	}
	

	
}
