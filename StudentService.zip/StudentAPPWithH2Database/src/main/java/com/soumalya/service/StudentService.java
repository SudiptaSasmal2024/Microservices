package com.soumalya.service;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.soumalya.dao.StudentDao;
import com.soumalya.dto.StudentDTO;
import com.soumalya.entity.StudentEntity;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class StudentService {

	@Autowired
	private StudentDao studentDao;

	private ModelMapper mapper = new ModelMapper();

	public void addStudent(StudentDTO student) {
		log.info("In Service Method {}", student);
		student.setName(student.getName().toUpperCase());
		StudentEntity entity = mapper.map(student, StudentEntity.class);
		studentDao.addStudent(entity);
	}
	///
	public Optional<StudentEntity> verifyById(Integer id) {
		return studentDao.verifyId(id);
	}
	////
	public List<StudentEntity> getAll() {
		return studentDao.getAllStudents();
	}
	
	public boolean deleteStudent(Integer id) {
		return studentDao.deleteStudent(id);
	}
	public List<StudentEntity> verifyByCity(String city) {
		// TODO Auto-generated method stub
		return studentDao.findByCity(city);
	}
}
