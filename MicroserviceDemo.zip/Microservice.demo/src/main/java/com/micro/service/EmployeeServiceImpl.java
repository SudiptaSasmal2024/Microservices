package com.micro.service;

import java.util.List;

import com.micro.entity.EmployeeEntity;
import com.micro.repository.EmployeeRepository;

public class EmployeeServiceImpl implements EmployeeSertvice{

	
	private EmployeeRepository employeeRepository;
	@Override
	public EmployeeEntity createEmployee(EmployeeEntity employeeEntity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeEntity> getAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeEntity getOne(Integer empId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<EmployeeEntity> getByDeptId(Integer deptId) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
