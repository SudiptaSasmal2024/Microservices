package com.micro.service;

import java.util.List;

import com.micro.entity.EmployeeEntity;

public interface EmployeeSertvice{
	
	EmployeeEntity createEmployee(EmployeeEntity employeeEntity);
	public List<EmployeeEntity> getAll();
	public EmployeeEntity getOne(Integer empId);
	List <EmployeeEntity> getByDeptId(Integer deptId);
}