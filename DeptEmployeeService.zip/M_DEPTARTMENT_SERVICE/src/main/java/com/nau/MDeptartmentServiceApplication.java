package com.nau;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MDeptartmentServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MDeptartmentServiceApplication.class, args);
	}

}
