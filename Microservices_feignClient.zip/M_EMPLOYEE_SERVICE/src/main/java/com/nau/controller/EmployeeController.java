package com.nau.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.nau.entity.EmployeeEntity;
import com.nau.service.EmployeeService;
import com.nau.vo.EmployeeDepartmentVO;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@PostMapping
	public EmployeeEntity create(@RequestBody EmployeeEntity employeeEntity) {
		return employeeService.createEmployee(employeeEntity);
	}
	
	@GetMapping
	public List<EmployeeEntity> getAll(){
		return employeeService.getAll();
	}
	
	@GetMapping("/byid/{empId}")
	public EmployeeEntity getOne(@PathVariable Integer empId) {
		
		return employeeService.getOne(empId);
	}
	
	@GetMapping("/getempwithdept/{empId}")
	public EmployeeDepartmentVO getEmployeeWithDepartment(@PathVariable Integer empId) {
		return employeeService.getEmployeeWithDepartmentInfoWithFeign(empId);
	}
	
	@GetMapping("bydeptid/{deptId}")
	public List<EmployeeEntity> getDepartmentById(@PathVariable Integer deptId){
		return employeeService.getByDeptId(deptId);
	}
}
