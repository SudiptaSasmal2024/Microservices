package com.nau;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.sql.Connection;

import org.junit.jupiter.api.Test;

import com.nau.utils.DBConnection;

public class ConnectionTest {
	
	@Test
	public void testConnection() {
		
		Connection connection = DBConnection.getConnection();
		assertNotNull(connection);
		
	}

}
