package com.nau;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.nau.service.GreetingService;

public class GreetingTest {
	
	@Test
	public void greetTest() {
		 
		GreetingService greeting = new GreetingService();
		String message = greeting.greet("Naushad");
		String expectedMessage = "HelloNaushad";
		assertEquals(expectedMessage,message);
	}
}
