package com.nau.main;

import java.util.Scanner;

import com.nau.viewcontroller.GreetController;

public class MainApp {
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Name:");
		String name=sc.next();
		GreetController controller = new GreetController();
		controller.greetings(name);
		
	}

}
