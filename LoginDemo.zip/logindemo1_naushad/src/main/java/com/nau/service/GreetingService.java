package com.nau.service;

public class GreetingService {
	
	public String greet(String name) {
		return "Hello "+ name;
	}
}
